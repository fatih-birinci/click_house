package com.clickhouse.client.config;

/**
 * Defines supported SSL mode.
 */
public enum ClickHouseProxyType {
    IGNORE, DIRECT, HTTP, SOCKS;
}
