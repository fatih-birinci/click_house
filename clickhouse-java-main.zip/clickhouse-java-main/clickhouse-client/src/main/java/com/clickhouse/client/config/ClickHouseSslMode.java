package com.clickhouse.client.config;

/**
 * Defines supported SSL mode.
 */
public enum ClickHouseSslMode {
    NONE, STRICT
}
