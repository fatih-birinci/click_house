/**
 * Provides necessary classes to configure the client and/or request.
 */
package com.clickhouse.client.config;
