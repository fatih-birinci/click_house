/**
 * Provides necessary classes to communicate with ClickHouse server.
 */
package com.clickhouse.client;
