/**
 * Provides configuration classes.
 */
package com.clickhouse.config;
