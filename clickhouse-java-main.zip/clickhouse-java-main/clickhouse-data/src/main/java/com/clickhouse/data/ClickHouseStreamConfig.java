package com.clickhouse.data;

public interface ClickHouseStreamConfig {

}
