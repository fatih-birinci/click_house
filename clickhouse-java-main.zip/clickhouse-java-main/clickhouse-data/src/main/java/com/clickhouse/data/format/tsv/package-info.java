/**
 * Provides necessary classes to handle TSV format.
 */
package com.clickhouse.data.format.tsv;
