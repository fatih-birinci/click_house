/**
 * Provides necessary classes to handle different format or type of data.
 */
package com.clickhouse.data.value;
