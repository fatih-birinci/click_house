/**
 * Provides logging classes.
 */
package com.clickhouse.logging;
