package com.clickhouse.client.http.config;

public enum HttpConnectionProvider {
    HTTP_CLIENT,
    HTTP_URL_CONNECTION,
    APACHE_HTTP_CLIENT
}
