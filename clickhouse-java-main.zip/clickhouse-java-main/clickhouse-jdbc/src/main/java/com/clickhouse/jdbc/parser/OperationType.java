package com.clickhouse.jdbc.parser;

public enum OperationType {
    UNKNOWN, READ, WRITE
}
