# ClickHouse R2DBC Driver

[R2DBC](https://r2dbc.io/) wrapper of async [Java client](/ClickHouse/clickhouse-java/clickhouse-client) for ClickHouse.

## Documentation
See the [ClickHouse website](https://clickhouse.com/docs/en/integrations/language-clients/java/r2dbc) for the full documentation entry.

## Examples
For more example please check [here](https://github.com/ClickHouse/clickhouse-java/tree/main/examples/r2dbc).
