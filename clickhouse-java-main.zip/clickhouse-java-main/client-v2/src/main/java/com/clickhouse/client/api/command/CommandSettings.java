package com.clickhouse.client.api.command;

import com.clickhouse.client.api.query.QuerySettings;

public class CommandSettings extends QuerySettings {
}
