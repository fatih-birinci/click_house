package com.clickhouse.client.api.enums;

public enum Protocol {
    HTTP
}
