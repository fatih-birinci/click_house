package com.clickhouse.client.api.enums;

public enum ProxyType {
    //DIRECT,
    HTTP,
    SOCKS;
}
